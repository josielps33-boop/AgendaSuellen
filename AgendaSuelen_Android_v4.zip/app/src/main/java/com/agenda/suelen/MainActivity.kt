package com.agenda.suelen

import android.Manifest
import android.app.*
import android.content.*
import android.graphics.Color
import android.net.Uri
import android.os.*
import android.provider.Settings
import android.view.*
import android.widget.*
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AppCompatActivity
import java.text.SimpleDateFormat
import java.util.*

data class Aula(var dia:Int,var inicio:String,var fim:String,var turma:String,var obs:String="",var lembrete:Boolean=true)

class MainActivity:AppCompatActivity(){
 private val p by lazy{getSharedPreferences("suelen",0)}
 private val aulas=mutableListOf(
  Aula(2,"08:50","09:30","7º A"),Aula(2,"09:45","10:25","6º G"),Aula(2,"11:05","11:45","7º C"),
  Aula(3,"07:30","08:10","6º E"),Aula(4,"07:30","08:10","7º B"),Aula(4,"08:10","08:50","6º A"),
  Aula(4,"08:50","09:30","6º C"),Aula(5,"07:30","08:10","6º F"),Aula(5,"08:10","08:50","6º D"),
  Aula(5,"10:25","11:05","6º B"),Aula(1,"14:50","15:30","9º C"),Aula(1,"17:05","17:45","8º C"),
  Aula(2,"14:10","14:50","8º A"),Aula(2,"17:05","17:45","7º D"),Aula(3,"13:30","14:10","9º A"),
  Aula(4,"14:50","15:30","7º E"),Aula(4,"16:25","17:05","8º D"),Aula(5,"14:50","15:30","8º B"),
  Aula(5,"15:45","16:25","9º B"),Aula(5,"16:25","17:05","7º F")
 )
 private val audioPicker=registerForActivityResult(ActivityResultContracts.OpenDocument()){u->
  u?:return@registerForActivityResult
  contentResolver.takePersistableUriPermission(u,Intent.FLAG_GRANT_READ_URI_PERMISSION)
  p.edit().putString("alarm_uri",u.toString()).apply();toast("Áudio selecionado.")
 }
 override fun onCreate(b:Bundle?){super.onCreate(b);if(Build.VERSION.SDK_INT>=33)requestPermissions(arrayOf(Manifest.permission.POST_NOTIFICATIONS),7);if(p.getBoolean("logged",false))home()else login()}
 private fun login(){
  val s=LinearLayout(this);s.orientation=LinearLayout.VERTICAL;s.gravity=Gravity.CENTER;s.setPadding(34,40,34,40)
  val logo=TextView(this);logo.text="👩‍🏫";logo.textSize=58f;logo.gravity=17
  val t=TextView(this);t.text="Agenda Suelen";t.textSize=30f;t.gravity=17
  val sub=TextView(this);sub.text="Seu assistente de aulas";sub.gravity=17
  val n=EditText(this);n.hint="Nome";n.setText(p.getString("name","Suelen"))
  val pin=EditText(this);pin.hint="PIN de 6 números";pin.inputType=2;pin.maxLength=6
  val bt=Button(this);bt.text="ENTRAR";bt.setAllCaps(false)
  s.addView(logo);s.addView(t);s.addView(sub);s.addView(n);s.addView(pin);s.addView(bt);setContentView(s)
  bt.setOnClickListener{if(pin.text.toString()==p.getString("pin","123456")&&pin.text.length==6){p.edit().putBoolean("logged",true).putString("name",n.text.toString()).apply();home()}else toast("PIN incorreto.")}
 }
 private fun home(){
  val scroll=ScrollView(this);val box=LinearLayout(this);box.orientation=LinearLayout.VERTICAL;box.setPadding(20,20,20,30)
  val header=LinearLayout(this);header.gravity=Gravity.CENTER_VERTICAL
  val photo=TextView(this);photo.text=p.getString("emoji","👩‍🏫");photo.textSize=42f
  val texts=LinearLayout(this);texts.orientation=LinearLayout.VERTICAL
  val name=TextView(this);name.text=p.getString("name","Suelen");name.textSize=26f
  val prof=TextView(this);prof.text=p.getString("prof","Professora de Ensino Religioso");prof.textSize=15f
  texts.addView(name);texts.addView(prof);header.addView(photo);header.addView(texts);box.addView(header)
  val now=Calendar.getInstance();val dow=now.get(Calendar.DAY_OF_WEEK)
  val today=aulas.filter{it.dia==dow}.sortedBy{it.inicio}
  val card=TextView(this);card.text="\n📚 AULAS DE HOJE\n${if(today.isEmpty())"Nenhuma aula hoje." else today.joinToString("\n"){ "  ${it.inicio}  •  ${it.turma}"}}";card.textSize=18f;box.addView(card)
  val clock=TextView(this);clock.text="\n🕒 "+SimpleDateFormat("EEEE, dd/MM • HH:mm",Locale("pt","BR")).format(Date());box.addView(clock)
  val b1=Button(this);b1.text="⏳  PRÓXIMA AULA";b1.setAllCaps(false)
  val b2=Button(this);b2.text="🔔  CENTRAL DE ALERTAS";b2.setAllCaps(false)
  val b3=Button(this);b3.text="📅  MINHA AGENDA";b3.setAllCaps(false)
  val b4=Button(this);b4.text="👤  PERFIL E CONFIGURAÇÕES";b4.setAllCaps(false)
  val out=Button(this);out.text="🚪  SAIR";out.setAllCaps(false)
  listOf(b1,b2,b3,b4,out).forEach{box.addView(it)}
  scroll.addView(box);setContentView(scroll)
  b1.setOnClickListener{nextDialog()};b2.setOnClickListener{alertsDialog()};b3.setOnClickListener{agendaDialog()};b4.setOnClickListener{profileDialog()}
  out.setOnClickListener{p.edit().putBoolean("logged",false).apply();login()}
 }
 private fun nextDialog(){
  val now=Calendar.getInstance();var best:Aula?=null;var ms=Long.MAX_VALUE
  aulas.forEach{a->val c=Calendar.getInstance();c.set(Calendar.DAY_OF_WEEK,a.dia);val q=a.inicio.split(":");c.set(Calendar.HOUR_OF_DAY,q[0].toInt());c.set(Calendar.MINUTE,q[1].toInt());c.set(Calendar.SECOND,0);if(c.timeInMillis<=now.timeInMillis)c.add(Calendar.WEEK_OF_YEAR,1);if(c.timeInMillis<ms){ms=c.timeInMillis;best=a}}
  AlertDialog.Builder(this).setTitle("⏳ Próxima aula").setMessage("${best?.turma}\n${best?.inicio}–${best?.fim}\n\nFaltam aproximadamente ${(ms-now.timeInMillis)/60000} minutos.").setPositiveButton("OK",null).show()
 }
 private fun alertsDialog(){
  val uri=p.getString("alarm_uri",null)
  val msg="🔔 Alertas configurados\n\n• 1 hora antes\n• 15 minutos antes\n• 5 minutos antes\n• No início da aula\n\n🎵 Áudio: ${if(uri==null)"Som padrão" else "Áudio personalizado"}"
  AlertDialog.Builder(this).setTitle("Central de alertas").setMessage(msg).setPositiveButton("ATIVAR / ATUALIZAR"){_,_->AlarmScheduler(this).scheduleAll(aulas);toast("Alertas atualizados.")}.setNeutralButton("Escolher áudio"){_,_->audioPicker.launch(arrayOf("audio/*"))}.setNegativeButton("Fechar",null).show()
 }
 private fun agendaDialog(){
  val days=mapOf(2 to "SEGUNDA",3 to "TERÇA",4 to "QUARTA",5 to "QUINTA",6 to "SEXTA")
  val msg=StringBuilder()
  days.forEach{(d,n)->msg.append("\n$n\n");aulas.filter{it.dia==d}.sortedBy{it.inicio}.forEach{msg.append("• ${it.inicio}–${it.fim} → ${it.turma}\n")}}
  AlertDialog.Builder(this).setTitle("📅 Agenda semanal").setMessage(msg.toString()).setPositiveButton("OK",null).show()
 }
 private fun profileDialog(){
  val l=LinearLayout(this);l.orientation=LinearLayout.VERTICAL;l.setPadding(24,5,24,5)
  fun e(v:String,h:String)=EditText(this).apply{setText(v);hint=h}
  val n=e(p.getString("name","Suelen"),"Nome");val pr=e(p.getString("prof","Professora de Ensino Religioso"),"Profissão / disciplina");val em=e(p.getString("emoji","👩‍🏫"),"Emoji");val pin=e(p.getString("pin","123456"),"PIN de 6 números");pin.inputType=2;pin.maxLength=6
  val audio=Button(this);audio.text="🎵 Escolher áudio do alarme";l.addView(n);l.addView(pr);l.addView(em);l.addView(pin);l.addView(audio)
  audio.setOnClickListener{audioPicker.launch(arrayOf("audio/*"))}
  AlertDialog.Builder(this).setTitle("👤 Perfil").setView(l).setPositiveButton("SALVAR"){_,_->if(pin.text.length==6)p.edit().putString("name",n.text.toString()).putString("prof",pr.text.toString()).putString("emoji",em.text.toString()).putString("pin",pin.text.toString()).apply();toast("Perfil salvo.")}.setNegativeButton("Cancelar",null).show()
 }
 private fun toast(x:String)=Toast.makeText(this,x,Toast.LENGTH_SHORT).show()
}
