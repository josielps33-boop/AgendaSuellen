Agenda Suelen Android v4 — interface principal integrada.
Login, PIN, perfil, emoji, profissão, agenda semanal, próxima aula, central de alertas, áudio personalizado e 19 aulas cadastradas.
Abra no Android Studio, sincronize o Gradle e gere o APK em Build > Build APK(s).
