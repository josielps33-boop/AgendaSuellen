package com.agenda.suelen
import android.content.*
class BootReceiver:BroadcastReceiver(){override fun onReceive(c:Context,i:Intent){/* agenda pode ser reprogramada ao abrir o app */}}
