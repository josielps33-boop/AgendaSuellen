package com.agenda.suelen
import android.app.*;import android.content.*;import java.util.*
class AlarmScheduler(private val c:Context){
 private val am=c.getSystemService(AlarmManager::class.java)
 fun scheduleAll(list:List<Aula>){list.forEachIndexed{i,a->listOf(60,15,5,0).forEach{schedule(i,a,it)}}}
 private fun schedule(i:Int,a:Aula,b:Int){
  val x=Calendar.getInstance();val q=a.inicio.split(":");x.set(Calendar.DAY_OF_WEEK,a.dia);x.set(Calendar.HOUR_OF_DAY,q[0].toInt());x.set(Calendar.MINUTE,q[1].toInt());x.set(Calendar.SECOND,0);x.set(Calendar.MILLISECOND,0);x.add(Calendar.MINUTE,-b);while(x.timeInMillis<=System.currentTimeMillis())x.add(Calendar.WEEK_OF_YEAR,1)
  val inx=Intent(c,AlarmReceiver::class.java).putExtra("class_name",a.turma).putExtra("class_time",a.inicio).putExtra("minutes_before",b)
  val pi=PendingIntent.getBroadcast(c,i*10+b,inx,PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE)
  if(Build.VERSION.SDK_INT>=23)am.setExactAndAllowWhileIdle(AlarmManager.RTC_WAKEUP,x.timeInMillis,pi)else am.setExact(AlarmManager.RTC_WAKEUP,x.timeInMillis,pi)
 }
}
